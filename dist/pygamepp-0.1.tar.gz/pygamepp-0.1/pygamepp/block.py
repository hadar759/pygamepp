class Block:
    def __init__(self, x: int, y: int, occupied: bool):
        self.x = x
        self.y = y
        self.occupied = occupied
