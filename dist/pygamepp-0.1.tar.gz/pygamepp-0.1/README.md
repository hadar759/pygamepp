Just uploaded this for now because i hadn't uploaded it yet to PyPi, might be useful for the future too.
This is a cute little wrapper i'm making for Pygame, to ease my future projects :3